using Xunit;
using StringManipulation;

public class PruebasOperacionesTexto
{
    // Pruebas para ConcatenateStrings
    [Theory]  
    [InlineData("Hola", " Mundo", "Hola Mundo")]
    [InlineData("", "prueba", "prueba")]
    [InlineData("prueba", "", "prueba")]
    
    public void ConcatenarTextos_DebeConcatenarDosTextos(string texto1, string texto2, string resultadoEsperado)
    {
        // Arrange
        var operacionesTexto = new StringOperations();

        // Act
        var resultado = operacionesTexto.ConcatenateStrings(texto1, texto2); 

        // Assert
        Assert.Equal(resultadoEsperado, resultado); //Comprobacion
    }

    // Pruebas para ReverseString
    [Theory]
    [InlineData("hola", "aloh")]
    [InlineData("", "")]
    [InlineData("isa", "asi")]
    public void InvertirTexto_DebeInvertirEntrada(string entrada, string resultadoEsperado)
    {
        // Arrange
        var operacionesTexto = new StringOperations();

        // Act
        var resultado = operacionesTexto.ReverseString(entrada);

        // Assert
        Assert.Equal(resultadoEsperado, resultado);
    }

    // Pruebas para IsPalindrome
    [Theory]
    [InlineData("ana", true)]
    [InlineData("hola", false)]
    [InlineData("", true)]
    [InlineData("a", true)]
    public void EsPalindromo_DebeDetectarPalindromos(string entrada, bool resultadoEsperado)
    {
        // Arrange
        var operacionesTexto = new StringOperations();

        // Act
        var resultado = operacionesTexto.IsPalindrome(entrada);

        // Assert
        Assert.Equal(resultadoEsperado, resultado);
    }

    // Pruebas para RemoveWhitespace
    [Theory]
    [InlineData("hello world", "helloworld")]
    [InlineData("   spaces   ", "spaces")]
    [InlineData("", "")]
    public void RemoveWhitespace_ShouldRemoveAllSpaces(string input, string expected)
    {
        // Arrange
        var stringOps = new StringOperations();

        // Act
        var result = stringOps.RemoveWhitespace(input);

        // Assert
        Assert.Equal(expected, result);
    }

    // Pruebas para ReadFile usando Mock
    [Fact]
    public void ReadFile_ShouldReturnFileContent()
    {
        // Arrange
        var mockFileReader = new Mock<IFileReaderConnector>();
        mockFileReader.Setup(x => x.ReadAllText(It.IsAny<string>()))
                        .Returns("test content");
        var stringOps = new StringOperations(mockFileReader.Object);

        // Act
        var result = stringOps.ReadFile("test.txt");

        // Assert
        Assert.Equal("test content", result);
        mockFileReader.Verify(x => x.ReadAllText("test.txt"), Times.Once());
    }

    // Prueba de excepción
    [Fact]
    public void TruncateString_ShouldThrowException_WhenMaxLengthIsNegative()
    {
        // Arrange
        var stringOps = new StringOperations();

        // Act & Assert
        Assert.Throws<ArgumentException>(() => 
            stringOps.TruncateString("test", -1));
    }
}
